#wolf
import bs
from bsMap import *
import bsMap

def __init__(self, vrOverlayCenterOffset=None):
        """
        Instantiate a map.
        """
        import bsInternal
        bs.Actor.__init__(self)
        self.preloadData = self.preload(onDemand=True)
        def text():
                #bySoby
                t = bs.newNode('text',
                       attrs={ 'text':u"\ue043SERVER BY ROCKY\ue043",
                              'scale':0.8,
                              'maxWidth':0,
                              'position':(0,635),
                              'shadow':0.3,
                              'flatness':1.0,
                              'color':(1,1,1),
                              'hAlign':'center',
                              'vAttach':'bottom'})
                bs.animate(t,'opacity',{0: 0.0,500: 1.0,100000: 1.0,100500: 0.0})
                bs.gameTimer(1000500,t.delete)
                ##
                t = bs.newNode('text',
                       attrs={ 'text':u'\ue048OWNED & EDITED BY ROCKY\ue048',
                              'scale':0.7,
                              'maxWidth':0,
                              'position':(0,610),
                              'shadow':0.0,
                              'flatness':0.5,
                              'color':(1,1,1),
                              'hAlign':'center',
                              'vAttach':'bottom'})
                bs.animate(t,'opacity',{0: 0.0,500: 1.0,100000: 1.0,100500: 0.0})
                bs.gameTimer(100500,t.delete)
                #bySoby
                t = bs.newNode('text',
                       attrs={ 'text':u"\ue043WELCOME TO SERVER BY ROCKY\ue043",
                              'scale':0.9,
                              'maxWidth':0,
                              'position':(0,100),
                              'color':(1,1,1),
                              'shadow':0,
                              'flatness':1.0,
                              'hAlign':'center',
                              'vAttach':'bottom'})
                bs.animate(t,'opacity',{0: 0.0,500: 1.0,10500: 1.0,11000: 0.0})
                bs.gameTimer(11000,t.delete)
                #bySoby
                t = bs.newNode('text',
                       attrs={ 'text':u'\ue048ABUSERS WILL BE KICKED AND BE RANK 1 FOR ADMIN\ue048',
                              'scale':0.8,
                              'maxWidth':0,
                              'position':(0,108),
                              'shadow':0,
                              'flatness':0.9,
                              'hAlign':'center',
                              'vAttach':'bottom'})
                bs.animate(t,'opacity',{13000: 0.0,13500: 1.0,23500: 1.0,24000: 0.0})
                bs.gameTimer(24000,t.delete)
                t = bs.newNode('text',
                       attrs={ 'text':u'\ue043JOIN IN OUR DISCORD SERVER THROUGH STATS\ue048',
                              'scale':1.0,
                              'maxWidth':0,
                              'position':(0,108),
                              'shadow':0.3,
                              'flatness':0.9,
                              'hAlign':'center',
                              'vAttach':'bottom'})
                bs.animate(t,'opacity',{26000: 0.0,26500: 1.0,36500: 1.0,37000: 0.0})
                bs.gameTimer(37000,t.delete)
        bs.gameTimer(3500,bs.Call(text))
        bs.gameTimer(42000,bs.Call(text),repeat = True)
        
        # set some defaults
        bsGlobals = bs.getSharedObject('globals')
        # area-of-interest bounds
        aoiBounds = self.getDefBoundBox("areaOfInterestBounds")
        if aoiBounds is None:
            print 'WARNING: no "aoiBounds" found for map:',self.getName()
            aoiBounds = (-1,-1,-1,1,1,1)
        bsGlobals.areaOfInterestBounds = aoiBounds
        # map bounds
        mapBounds = self.getDefBoundBox("levelBounds")
        if mapBounds is None:
            print 'WARNING: no "levelBounds" found for map:',self.getName()
            mapBounds = (-30,-10,-30,30,100,30)
        bsInternal._setMapBounds(mapBounds)
        # shadow ranges
        try: bsGlobals.shadowRange = [
                self.defs.points[v][1] for v in 
                ['shadowLowerBottom','shadowLowerTop',
                 'shadowUpperBottom','shadowUpperTop']]
        except Exception: pass
        # in vr, set a fixed point in space for the overlay to show up at..
        # by default we use the bounds center but allow the map to override it
        center = ((aoiBounds[0]+aoiBounds[3])*0.5,
                  (aoiBounds[1]+aoiBounds[4])*0.5,
                  (aoiBounds[2]+aoiBounds[5])*0.5)
        if vrOverlayCenterOffset is not None:
            center = (center[0]+vrOverlayCenterOffset[0],
                      center[1]+vrOverlayCenterOffset[1],
                      center[2]+vrOverlayCenterOffset[2])
        bsGlobals.vrOverlayCenter = center
        bsGlobals.vrOverlayCenterEnabled = True
        self.spawnPoints = self.getDefPoints("spawn") or [(0,0,0,0,0,0)]
        self.ffaSpawnPoints = self.getDefPoints("ffaSpawn") or [(0,0,0,0,0,0)]
        self.spawnByFlagPoints = (self.getDefPoints("spawnByFlag")
                                  or [(0,0,0,0,0,0)])
        self.flagPoints = self.getDefPoints("flag") or [(0,0,0)]
        self.flagPoints = [p[:3] for p in self.flagPoints] # just want points
        self.flagPointDefault = self.getDefPoint("flagDefault") or (0,1,0)
        self.powerupSpawnPoints = self.getDefPoints("powerupSpawn") or [(0,0,0)]
        self.powerupSpawnPoints = \
            [p[:3] for p in self.powerupSpawnPoints] # just want points
        self.tntPoints = self.getDefPoints("tnt") or []
        self.tntPoints = [p[:3] for p in self.tntPoints] # just want points
        self.isHockey = False
        self.isFlying = False
        self._nextFFAStartIndex = 0
        
bsMap.Map.__init__ = __init__
