damage = []
heal = None
healthpo = []


